circleData = [
{
    "groupName": "摊位区-魅",
    "groupDescription": "官方摊位区",
    "boothsCategory": [
    {
        "name": "",
        "color": "#66ccff",
        "booths": [
        {
            "img": "./image/circles/MEI_01.jpg",
            "name": "魅知幻想之旅",
            "description": "魅-1/2",
            "tags":["双日","集章"],
            "link": "http://thonly.name/"
        },
        {
            "img": "./image/circles/MEI_03.jpg",
            "name": "幻奏盛宴",
            "tags":["双日","集章"],
            "description": "魅-3/4",
            "link": "http://touhou-symphony.net/"
        },
        {
            "img": "./image/circles/MEI_05.jpg",
            "name": "THB梦缘社",
            "tags":["双日","集章"],
            "description": "魅-5/6",
            "link": "http://thwiki.cc"
        },
        {
            "img": "./image/circles/MEI_07.jpg",
            "name": "京都幻想剧团",
            "tags":["双日","集章"],
            "description": "魅-7/8",
            "link": "http://kyotofantasytroupe.net"
        },
        {
            "img": "./image/circles/MEI_09.jpg",
            "name": "东深见桌游部",
            "tags":["双日","集章"],
            "description": "魅-9/10",
            "link": "https://jq.qq.com/?_wv=1027&k=icncVFFP"
        },
        {
            "img": "./image/circles/MEI_11.jpg",
            "name": "铃奈庵书屋",
            "tags":["双日","集章"],
            "description": "魅-11/12",
            "link": "http://touhou.taobao.com"
        }
        ]
    }]
},
{
    "groupName": "摊位区-梦",
    "groupDescription": "音乐社团区",
    "boothsCategory": [
    {
        "name": "",
        "color": "#66ccff",
        "booths": [
            {
                "img": "./image/circles/MENG_02.jpg",
                "name": "orugoru1919",
                "tags":["双日"],
                "description": "梦-2",
                "link": ""
            },
            {
                "img": "./image/circles/MENG_03.jpg",
                "name": "幻想跃迁实验室",
                "tags":["双日","集章"],
                "description": "梦-3/4",
                "link": ""
            },
            {
                "img": "./image/circles/MENG_05.jpg",
                "name": "境界36号",
                "tags":["双日","集章"],
                "description": "梦-5",
                "link": ""
            },
            {
                "img": "./image/circles/MENG_06.jpg",
                "name": "疯帽子茶会",
                "tags":["双日","集章"],
                "description": "梦-6/7",
                "link": ""
            },
            {
                "img": "./image/circles/MENG_08.jpg",
                "name": "幻想诗篇Xanadu Canto",
                "tags":["双日","集章"],
                "description": "梦-8",
                "link": ""
            },
            {
                "img": "./image/circles/MENG_09.jpg",
                "name": "Crest",
                "tags":["双日"],
                "description": "梦-9",
                "link": ""
            },
            {
                "img": "./image/circles/MENG_10.jpg",
                "name": "bunny rhyTHm",
                "tags":["双日","集章"],
                "description": "梦-10/11",
                "link": ""
            },
            {
                "img": "./image/circles/MENG_12.jpg",
                "name": "Yonder Voice",
                "tags":["双日","集章"],
                "description": "梦-12～14",
                "link": "https://space.bilibili.com/210232"
            },
            {
                "img": "./image/circles/MENG_15.jpg",
                "name": "TsuBaKi",
                "tags":["双日","集章"],
                "description": "梦-15/16",
                "link": ""
            },
            {
                "img": "./image/circles/MENG_17.jpg",
                "name": "DualInsomiNa",
                "tags":["双日","集章"],
                "description": "梦-17/18",
                "link": ""
            },
            {
                "img": "./image/circles/MENG_19.jpg",
                "name": "ジャージと愉快な仲間たち",
                "tags":["双日","集章"],
                "description": "梦-19",
                "link": ""
            },
            {
                "img": "./image/circles/MENG_20.jpg",
                "name": "煙霞",
                "tags":["双日","集章"],
                "description": "梦-20/21（D1）\n梦～20/22（D2）",
                "link": ""
            },
            {
                "img": "./image/circles/MENG_22.jpg",
                "name": "四叶工造",
                "tags":["Day1","集章"],
                "description": "梦-22",
                "link": ""
            },
            {
                "img": "./image/circles/MENG_23.jpg",
                "name": "LiberalSpark",
                "tags":["双日","集章"],
                "description": "梦-23",
                "link": ""
            },
            {
                "img": "./image/circles/MENG_24.jpg",
                "name": "Static World",
                "tags":["双日","集章"],
                "description": "梦-24/25",
                "link": ""
            },
            {
                "img": "./image/circles/MENG_26.jpg",
                "name": "赤音羽",
                "tags":["双日","集章"],
                "description": "梦-26",
                "link": ""
            },
            {
                "img": "./image/circles/MENG_27.jpg",
                "name": "BamBoO2丿VOICE",
                "tags":["双日","集章"],
                "description": "梦-2",
                "link": ""
            }
        ]
    }]
},
{
    "groupName": "摊位区-恋",
    "groupDescription": "音乐与桌游区",
    "boothsCategory": [
    {
        "name": "旧地狱食街",
        "textColor": "#7588ba",
        "color": "#66ccff",
        "booths": [{
            "img": "./image/circles/LIAN_01.jpg",
            "name": "Nami Haven",
            "tags":["双日"],
            "description": "恋-1",
            "link": "https://www.namihaven.com/"
        },
        {
            "img": "./image/circles/LIAN_02.jpg",
            "name": "鴛鴦ミルクティー",
            "tags":["双日"],
            "description": "恋-2",
            "link": ""
        },
        {
            "img": "./image/circles/LIAN_03.jpg",
            "name": "PSYSIA",
            "tags":["双日","集章"],
            "description": "恋-3",
            "link": ""
        },
        {
            "img": "./image/circles/LIAN_04.jpg",
            "name": "NFTO&秋叶室内乐团",
            "tags":["双日"],
            "description": "恋-4/5",
            "link": ""
        },
        {
            "img": "./image/circles/LIAN_06.jpg",
            "name": "槐安超特急",
            "tags":["双日","集章"],
            "description": "恋-6",
            "link": ""
        },
        {
            "img": "./image/circles/LIAN_07.jpg",
            "name": "焦味芝麻糊",
            "tags":["双日"],
            "description": "恋-7",
            "link": ""
        },
        {
            "img": "./image/circles/LIAN_08.jpg",
            "name": "梦现彼岸结界社",
            "tags":["双日","集章"],
            "description": "恋-8",
            "link": ""
        },
        {
            "img": "./image/circles/LIAN_09.jpg",
            "name": "Coloured Glaze",
            "tags":["双日","集章"],
            "description": "恋-9",
            "link": ""
        },
        {
            "img": "./image/circles/LIAN_10.jpg",
            "name": "醉梦笔笺",
            "tags":["双日","集章"],
            "description": "恋-10/11",
            "link": ""
        },
        {
            "img": "./image/circles/LIAN_12.jpg",
            "name": "槐南茶馆",
            "tags":["双日","集章"],
            "description": "恋-12/13",
            "link": "https://www.bilibili.com/video/BV1eV4116772"
        },
        {
            "img": "./image/circles/LIAN_14.jpg",
            "name": "Scharlachrot Kammermusik",
            "tags":["双日","集章"],
            "description": "恋-14",
            "link": ""
        }]
    },
    {
        "name": "",
        "color": "#66ccff",
        "booths": [
            {
                "img": "./image/circles/LIAN_15.jpg",
                "name": "XP社",
                "tags":["双日","集章"],
                "description": "恋-15～17",
                "link": ""
            },
            {
                "img": "./image/circles/LIAN_18.jpg",
                "name": "丝风 ProjectZephyr",
                "tags":["双日","集章"],
                "description": "恋-18/19",
                "link": ""
            },
            {
                "img": "./image/circles/LIAN_20.jpg",
                "name": "Tri-eye",
                "tags":["双日","集章"],
                "description": "恋-20～22",
                "link": ""
            },
            {
                "img": "./image/circles/LIAN_23.jpg",
                "name": "星之实验室",
                "tags":["双日","集章"],
                "description": "恋-23",
                "link": ""
            },
            {
                "img": "./image/circles/LIAN_24.jpg",
                "name": "油库里红茶馆",
                "tags":["双日","集章"],
                "description": "恋-24",
                "link": ""
            },
            {
                "img": "./image/circles/LIAN_25.jpg",
                "name": "东方寓梦粹",
                "tags":["双日"],
                "description": "恋-25",
                "link": ""
            },
            {
                "img": "./image/circles/LIAN_26.jpg",
                "name": "彩音~xi-on~",
                "tags":["双日","集章"],
                "description": "恋-26/27",
                "link": ""
            }
        ]
    }]
},
{
    "groupName": "摊位区-奇",
    "groupDescription": "日本社团区",
    "boothsCategory": [
    {
        "name": "",
        "color": "#66ccff",
        "booths": [
            {
                "img": "./image/circles/QI_01.jpg",
                "name": "COOL&CREATE",
                "tags":["双日","集章"],
                "description": "奇-1～3",
                "link": ""
            },
            {
                "img": "./image/circles/QI_04.jpg",
                "name": "豚乙女",
                "tags":["双日","集章"],
                "description": "奇-4/5",
                "link": ""
            },
            {
                "img": "./image/circles/QI_06.jpg",
                "name": "石鹸屋",
                "tags":["双日","集章"],
                "description": "奇-6/7",
                "link": ""
            },
            {
                "img": "./image/circles/QI_08.jpg",
                "name": "岸田教团",
                "tags":["双日","集章"],
                "description": "奇-8/9",
                "link": ""
            },
            {
                "img": "./image/circles/QI_10.jpg",
                "name": "DiGiTAL WiNG",
                "tags":["双日","集章"],
                "description": "奇-10/11",
                "link": ""
            },
            {
                "img": "./image/circles/QI_12.jpg",
                "name": "あぶら畑グランテッド",
                "tags":["双日","集章"],
                "description": "奇-12",
                "link": ""
            },
            {
                "img": "./image/circles/QI_13.jpg",
                "name": "北国もやし製造所",
                "tags":["双日","集章"],
                "description": "奇-13/14",
                "link": ""
            },
            {
                "img": "./image/circles/QI_15.jpg",
                "name": "kiroro",
                "tags":["双日","集章"],
                "description": "奇-15/16",
                "link": ""
            },
            {
                "img": "./image/circles/QI_17.jpg",
                "name": "だおだおだお",
                "tags":["双日","集章"],
                "description": "奇-17",
                "link": ""
            },
            {
                "img": "./image/circles/QI_18.jpg",
                "name": " ねことうふ猫豆腐",
                "tags":["双日","集章"],
                "description": "奇-18/19",
                "link": ""
            },
            {
                "img": "./image/circles/QI_20.jpg",
                "name": "SOUND HOLIC",
                "tags":["双日","集章"],
                "description": "奇-20/21",
                "link": ""
            },
            {
                "img": "./image/circles/QI_22.jpg",
                "name": "Melodic Taste",
                "tags":["双日","集章"],
                "description": "奇-22",
                "link": ""
            },
            {
                "img": "./image/circles/QI_23.jpg",
                "name": "Hachimitsu-Lemon",
                "tags":["双日","集章"],
                "description": "奇-23",
                "link": ""
            },
            {
                "img": "./image/circles/QI_24.jpg",
                "name": "TUMENECO",
                "tags":["双日","集章"],
                "description": "奇-24",
                "link": ""
            },
            {
                "img": "./image/circles/QI_25.jpg",
                "name": "R-note",
                "tags":["双日","集章"],
                "description": "奇-25/26",
                "link": ""
            },
            {
                "img": "./image/circles/QI_27.jpg",
                "name": "ActiveNEETs",
                "tags":["双日","集章"],
                "description": "奇-27/28",
                "link": ""
            }            
        ]
    }]
},

{
    "groupName": "摊位区-灵",
    "groupDescription": "",
    "boothsCategory": [
    {
        "name": "",
        "color": "#66ccff",
        "booths": [
            {
                "img": "./image/circles/LING_01.jpg",
                "name": "妖怪世界",
                "tags":["双日","集章"],
                "description": "灵-1～3",
                "link": ""
            },
            {
                "img": "./image/circles/LING_04.jpg",
                "name": "双心物语",
                "tags":["双日","集章"],
                "description": "灵-4/5",
                "link": ""
            },
            {
                "img": "./image/circles/LING_06.jpg",
                "name": "水星弹球酒吧",
                "tags":["双日","集章"],
                "description": "灵-6",
                "link": ""
            },
            {
                "img": "./image/circles/LING_07.jpg",
                "name": "小风的拼豆幻想",
                "tags":["双日","集章"],
                "description": "灵-7/8",
                "link": "https://weibo.com/u/7122621635"
            },
            {
                "img": "./image/circles/LING_09.jpg",
                "name": "MineCraft幻想乡",
                "tags":["双日","集章"],
                "description": "灵-9/10",
                "link": ""
            },
            {
                "img": "./image/circles/LING_11.jpg",
                "name": "此幻社",
                "tags":["双日","集章"],
                "description": "灵-11",
                "link": ""
            },
            {
                "img": "./image/circles/LING_12.jpg",
                "name": "花昙书社",
                "tags":["双日","集章"],
                "description": "灵-12",
                "link": ""
            },
            {
                "img": "./image/circles/LING_13.jpg",
                "name": "凝冰百合花纪录会",
                "tags":["双日"],
                "description": "灵-13",
                "link": ""
            },
            {
                "img": "./image/circles/LING_14.jpg",
                "name": "东方祈华梦制作组",
                "tags":["双日","集章"],
                "description": "灵-14",
                "link": ""
            },
            {
                "img": "./image/circles/LING_15.jpg",
                "name": "re零同人社",
                "tags":["双日","集章"],
                "description": "灵-15/16",
                "link": ""
            },
            {
                "img": "./image/circles/LING_17.jpg",
                "name": "二色幽紫蝶",
                "tags":["双日","集章"],
                "description": "灵-17～19",
                "link": ""
            },
            {
                "img": "./image/circles/LING_20.jpg",
                "name": "永动之龛",
                "tags":["双日","集章"],
                "description": "灵-20",
                "link": "https://weibo.com/forevershrine"
            },
            {
                "img": "./image/circles/LING_21.jpg",
                "name": "第零研究院",
                "tags":["双日","集章"],
                "description": "灵-21/22",
                "link": ""
            },
            {
                "img": "./image/circles/LING_23.jpg",
                "name": "恆萃工坊",
                "tags":["双日"],
                "description": "灵-23/24",
                "link": ""
            },
            {
                "img": "./image/circles/LING_25_01.jpg",
                "name": "紺青世界",
                "tags":["Day1","集章"],
                "description": "灵-25",
                "link": ""
            },
            {
                "img": "./image/circles/LING_25_02.jpg",
                "name": "栎融社",
                "tags":["Day2"],
                "description": "灵-25",
                "link": ""
            },
            {
                "img": "./image/circles/LING_26.jpg",
                "name": "Alice手工坊",
                "tags":["双日","集章"],
                "description": "灵-26",
                "link": ""
            },
            {
                "img": "./image/circles/LING_27.jpg",
                "name": "凝华手工坊",
                "tags":["双日"],
                "description": "灵-27",
                "link": ""
            },
            {
                "img": "./image/circles/LING_28.jpg",
                "name": "Epic-Works",
                "tags":["双日","集章"],
                "description": "灵-28",
                "link": ""
            }
        ]
    }]
},
{
    "groupName": "摊位区-时",
    "groupDescription": "",
    "boothsCategory": [
        {
            "name": "秘封街",
            "textColor": "#7588ba",
            "color": "#66ccff",
            "booths": [{
                "img": "./image/circles/SHI_01.jpg",
                "name": "星月中枢站SNC",
                "tags":["双日","集章"],
                "description": "时-1～3",
                "link": ""
            },
            {
                "img": "./image/circles/SHI_04.jpg",
                "name": "烟雨楼台",
                "tags":["双日","集章"],
                "description": "时-4",
                "link": ""
            },
            {
                "img": "./image/circles/SHI_05.jpg",
                "name": "猫与催眠术",
                "tags":["双日","集章"],
                "description": "时-5",
                "link": ""
            },
            {
                "img": "./image/circles/SHI_06.jpg",
                "name": "Virus-T",
                "tags":["双日","集章"],
                "description": "时-6",
                "link": ""
            },
            {
                "img": "./image/circles/SHI_07.jpg",
                "name": "群音绘Create",
                "tags":["双日","集章"],
                "description": "时-7",
                "link": "https://weibo.com/u/6965067886"
            }]
    },
    {
        "name": "地方社群区",
        "color": "#66ccff",
        "booths": [
        {
            "img": "./image/circles/SHI_08.jpg",
            "name": "无锡茶会东方吃喝睡组委会",
            "tags":["双日"],
            "description": "时-8",
            "link": ""
        },
        {
            "img": "./image/circles/SHI_09.jpg",
            "name": "东方苏酒宴",
            "tags":["双日"],
            "description": "时-9",
            "link": ""
        },
        {
            "img": "./image/circles/SHI_18.jpg",
            "name": "长沙THO沅芷湘兰",
            "tags":["双日"],
            "description": "时-10",
            "link": ""
        },
        {
            "img": "./image/circles/SHI_11.jpg",
            "name": "温州东方同好会",
            "tags":["双日"],
            "description": "时-11",
            "link": ""
        },
        {
            "img": "./image/circles/SHI_12.jpg",
            "name": "贵阳THO",
            "tags":["双日"],
            "description": "时-12",
            "link": ""
        },
        {
            "img": "./image/circles/SHI_13.jpg",
            "name": "郑州THO",
            "tags":["双日"],
            "description": "时-13",
            "link": ""
        },
        {
            "img": "./image/circles/SHI_14.jpg",
            "name": "幻响诗篇",
            "tags":["双日"],
            "description": "时-14",
            "link": ""
        },
        {
            "img": "./image/circles/SHI_15.jpg",
            "name": "深圳THO",
            "tags":["双日"],
            "description": "时-15",
            "link": ""
        },
        {
            "img": "./image/circles/SHI_16.jpg",
            "name": "鹤组",
            "tags":["双日"],
            "description": "时-16",
            "link": ""
        },
        {
            "img": "./image/circles/SHI_17.jpg",
            "name": "北京THO",
            "tags":["双日"],
            "description": "时-17",
            "link": ""
        },
        {
            "img": "./image/circles/SHI_10.jpg",
            "name": "长安THO延康衿歌",
            "tags":["双日"],
            "description": "时-18",
            "link": ""
        },
        {
            "img": "./image/circles/SHI_19.jpg",
            "name": "云南THO",
            "tags":["双日"],
            "description": "时-19",
            "link": ""
        },
        {
            "img": "./image/circles/SHI_20.jpg",
            "name": "武汉THO",
            "tags":["双日"],
            "description": "时-20",
            "link": ""
        },
        {
            "img": "./image/circles/SHI_21.jpg",
            "name": "青东会",
            "tags":["双日"],
            "description": "时-21",
            "link": ""
        },
        {
            "img": "./image/circles/SHI_22.jpg",
            "name": "广州THO",
            "tags":["双日"],
            "description": "时-22",
            "link": ""
        },
        {
            "img": "./image/circles/SHI_23.jpg",
            "name": "成都THO",
            "tags":["双日"],
            "description": "时-23",
            "link": ""
        },
        {
            "img": "./image/circles/SHI_24.jpg",
            "name": "浙江THO",
            "tags":["双日"],
            "description": "时-24",
            "link": ""
        },
        {
            "img": "./image/circles/SHI_25.jpg",
            "name": "大连THO",
            "tags":["双日"],
            "description": "时-25",
            "link": ""
        },
        {
            "img": "./image/circles/SHI_26.jpg",
            "name": "东方LiveParty",
            "tags":["双日"],
            "description": "时-26",
            "link": ""
        },
        {
            "img": "./image/circles/SHI_27.jpg",
            "name": "南京THO",
            "tags":["双日"],
            "description": "时-27",
            "link": ""
        },
        {
            "img": "./image/circles/SHI_28.jpg",
            "name": "福建THO",
            "tags":["双日"],
            "description": "时-28",
            "link": ""
        },
        {
            "img": "./image/circles/SHI_29.jpg",
            "name": "河北THO",
            "tags":["双日"],
            "description": "时-29",
            "link": ""
        }
        ],
    }
]
},
{
    "groupName": "摊位区-风",
    "groupDescription": "",
    "boothsCategory": [
    {
        "name": "",
        "color": "#66ccff",
        "booths": [{
            "img": "./image/circles/FENG_01.jpg",
            "name": "境界契约",
            "tags":["双日","集章"],
            "description": "风-1/2",
            "link": ""
        },
        {
            "img": "./image/circles/FENG_03.jpg",
            "name": "4C-Fantasy",
            "tags":["双日"],
            "description": "风-3/4",
            "link": ""
        },
        {
            "img": "./image/circles/FENG_05.jpg",
            "name": "灿华幻梦",
            "tags":["双日"],
            "description": "风-5",
            "link": ""
        },
        {
            "img": "./image/circles/FENG_06.jpg",
            "name": "PaperyLadyland",
            "tags":["双日","集章"],
            "description": "风-6",
            "link": ""
        },
        {
            "img": "./image/circles/FENG_07.jpg",
            "name": "幻梦缘起",
            "tags":["双日","集章"],
            "description": "风-7",
            "link": ""
        },
        {
            "img": "./image/circles/FENG_08.jpg",
            "name": "富士山失忆",
            "tags":["Day1"],
            "description": "风-8",
            "link": ""
        },
        {
            "img": "./image/circles/FENG_09.jpg",
            "name": "白楼印象",
            "tags":["双日","集章"],
            "description": "风-9/10（D1）\n风-8～10（D2）",
            "link": ""
        },
        {
            "img": "./image/circles/FENG_11.jpg",
            "name": "U235",
            "tags":["双日"],
            "description": "风-11/12",
            "link": ""
        },
        {
            "img": "./image/circles/FENG_13.jpg",
            "name": "MZ次元",
            "tags":["双日"],
            "description": "风-13/14",
            "link": ""
        },
        {
            "img": "./image/circles/FENG_15.jpg",
            "name": "CureLancy！",
            "tags":["双日"],
            "description": "风-15",
            "link": ""
        },
        {
            "img": "./image/circles/FENG_16.jpg",
            "name": "二维镜像",
            "tags":["双日"],
            "description": "风-16～19（D1）\n风-16～20（D2）",
            "link": ""
        },
        {
            "img": "./image/circles/FENG_20.jpg",
            "name": "麻薯小作坊",
            "tags":["Day1","集章"],
            "description": "风-20",
            "link": ""
        }
        ]
    }
]
}
]

